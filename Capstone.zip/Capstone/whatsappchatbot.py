from flask import Flask, request, Response, jsonify, render_template_string
from twilio.twiml.messaging_response import MessagingResponse
from pyngrok import ngrok, conf
import os
from dotenv import load_dotenv
import pandas as pd
import math
import sqlite3
from contextlib import contextmanager
import threading
import datetime
from dataclasses import dataclass
from enum import Enum
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from typing import Dict, Any, Optional, List
import json
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from functools import lru_cache
from sentence_transformers import SentenceTransformer
import faiss
import pickle
import hashlib
import plotly.express as px
import plotly.graph_objects as go
from datetime import timedelta

class RecommenderType(Enum):
    TFIDF = "tfidf"
    RAG = "rag"

class IntentClassificationType(Enum):
    RULE_BASED = "rule_based"
    MODEL_BASED = "model_based"

class MetadataExtractorType(Enum):
    RULE_BASED = "rule_based"
    MODEL_BASED = "model_based"

class SentimentAnalyzerType(Enum):
    RULE_BASED = "rule_based"
    BERT_MULTILINGUAL = "bert_multilingual"
    ROBERTA_TWITTER = "roberta_twitter"

@dataclass
class UserContext:
    user_number: str
    context: Dict[str, Any]
    timestamp: datetime.datetime
    
    def is_expired(self, expiry_duration: datetime.timedelta) -> bool:
        return datetime.datetime.now() - self.timestamp > expiry_duration

@dataclass
class ClassificationConfig:
    intent_type: IntentClassificationType = IntentClassificationType.RULE_BASED
    metadata_type: MetadataExtractorType = MetadataExtractorType.MODEL_BASED
    sentiment_type: SentimentAnalyzerType = SentimentAnalyzerType.BERT_MULTILINGUAL

class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()
    
    @contextmanager
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()
    
    def _init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Create conversations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_number TEXT NOT NULL,
                    profile_name TEXT NOT NULL,
                    user_message TEXT NOT NULL,
                    bot_response TEXT NOT NULL,
                    sentiment TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Create feedback table with improved structure
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_number TEXT NOT NULL,
                    profile_name TEXT NOT NULL,
                    feedback_text TEXT NOT NULL,
                    rating INTEGER CHECK (rating BETWEEN 1 AND 5),
                    category TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Create user_context table with better JSON handling
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_context (
                    user_number TEXT PRIMARY KEY,
                    context TEXT NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    session_id TEXT UNIQUE,
                    metadata TEXT
                )
            ''')
            
            conn.commit()

class UnifiedLLMEngine:
    def __init__(self, recommender_type: RecommenderType = RecommenderType.TFIDF,
                 config: ClassificationConfig = None):
        self.recommender_type = recommender_type
        self.config = config or ClassificationConfig()
        
        # Set initial device
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Set memory-efficient defaults for PyTorch
        if self.device == "cuda":
            torch.cuda.empty_cache()
            # Set environment variable for blocking CUDA launches
            os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
            # Enable memory efficient attention if using transformer models
            os.environ['PYTORCH_ENABLE_MEM_EFFICIENT_TF32'] = '1'
        
        # Initialize models with error handling
        self._init_models_with_fallback()
        
        # Initialize vectorizers and indexes
        self.setup_vectorizers()
        
        # Load product data
        self.load_product_data()

    def _init_models_with_fallback(self):
        """Initialize models with proper error handling and fallback mechanisms"""
        try:
            self._setup_intent_classifier()
            self._setup_query_model()
            self._setup_sentiment_analyzer()
            self._setup_embedding_model()
        except Exception as e:
            print(f"Error during model initialization: {str(e)}")
            # Force CPU mode if CUDA fails
            self.device = "cpu"
            print("Falling back to CPU for all models")
            self._setup_intent_classifier()
            self._setup_query_model()
            self._setup_sentiment_analyzer()
            self._setup_embedding_model()

    def _setup_intent_classifier(self):
        """Setup intent classification model with error handling"""
        if self.config.intent_type == IntentClassificationType.MODEL_BASED:
            try:
                model_kwargs = {
                    "low_cpu_mem_usage": True,
                    "torch_dtype": torch.float16 if self.device == "cuda" else torch.float32
                }
                self.intent_classifier = pipeline(
                    "zero-shot-classification",
                    model="facebook/bart-large-mnli",
                    device=self.device,
                    model_kwargs=model_kwargs
                )
            except Exception as e:
                print(f"Failed to load intent classifier on {self.device}, falling back to CPU: {str(e)}")
                self.device = "cpu"
                self.intent_classifier = pipeline(
                    "zero-shot-classification",
                    model="facebook/bart-large-mnli",
                    device="cpu",
                    model_kwargs={"low_cpu_mem_usage": True}
                )

    def _setup_query_model(self):
        """Setup query understanding model with error handling"""
        if self.config.metadata_type == MetadataExtractorType.MODEL_BASED:
            try:
                # Try loading TinyLlama/TinyLlama-1.1B-Chat-v1.0 first as it's smaller
                self.query_model = AutoModelForCausalLM.from_pretrained(
                    "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
                    torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                    device_map="auto" if self.device == "cuda" else None,
                    low_cpu_mem_usage=True
                )
                self.query_tokenizer = AutoTokenizer.from_pretrained("TinyLlama/TinyLlama-1.1B-Chat-v1.0")
            except Exception as e:
                print(f"Failed to load query model: {str(e)}, using CPU")
                self.device = "cpu"
                self.query_model = AutoModelForCausalLM.from_pretrained(
                    "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
                    torch_dtype=torch.float32,
                    device_map={"": "cpu"},
                    low_cpu_mem_usage=True
                )
                self.query_tokenizer = AutoTokenizer.from_pretrained("TinyLlama/TinyLlama-1.1B-Chat-v1.0")

    def _setup_sentiment_analyzer(self):
        """Setup sentiment analyzer with error handling"""
        if self.config.sentiment_type in [SentimentAnalyzerType.BERT_MULTILINGUAL, 
                                        SentimentAnalyzerType.ROBERTA_TWITTER]:
            try:
                model_name = ("nlptown/bert-base-multilingual-uncased-sentiment" 
                            if self.config.sentiment_type == SentimentAnalyzerType.BERT_MULTILINGUAL 
                            else "cardiffnlp/twitter-roberta-base-sentiment")
                
                self.sentiment_analyzer = pipeline(
                    "sentiment-analysis",
                    model=model_name,
                    device=self.device,
                    model_kwargs={
                        "low_cpu_mem_usage": True,
                        "torch_dtype": torch.float16 if self.device == "cuda" else torch.float32
                    }
                )
            except Exception as e:
                print(f"Failed to load sentiment model on {self.device}, falling back to CPU: {str(e)}")
                self.device = "cpu"
                self.sentiment_analyzer = pipeline(
                    "sentiment-analysis",
                    model=model_name,
                    device="cpu"
                )

    def _setup_embedding_model(self):
        """Setup embedding model with error handling"""
        if self.recommender_type == RecommenderType.RAG:
            try:
                self.embedding_model = SentenceTransformer(
                    'sentence-transformers/all-MiniLM-L6-v2',
                    device=self.device
                )
            except Exception as e:
                print(f"Failed to load embedding model on {self.device}, falling back to CPU: {str(e)}")
                self.device = "cpu"
                self.embedding_model = SentenceTransformer(
                    'sentence-transformers/all-MiniLM-L6-v2',
                    device="cpu"
                )

    def _create_prompt_general_query(self, query: str) -> str:
        """Create a structured prompt for intent analysis"""
        return f"""You are general query chatbot, reply to the query in consise form.
Query: "{query}"
Response:"""
    
    def generate_response(self, query: str) -> str:
        """Generate a response to the query using the language model"""
        if self.general_query_pipe:
            try:
                prompt = self._create_prompt_general_query(query)
                response = self.general_query_pipe(prompt, return_full_text=False)[0]['generated_text']
                return response.strip()
            except Exception as e:
                print(f"Response generation error: {str(e)}")
                return "I'm sorry, I couldn't process your request."
        else:
            print("Pipeline not initialized. Using fallback.")
            return "I'm sorry, I couldn't process your request."    
        
    def setup_vectorizers(self):
        """Setup vectorizers and indexes"""
        self.tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        
        if self.recommender_type == RecommenderType.RAG:
            # Initialize FAISS index
            self.product_embeddings = None
            self.faiss_index = None
    
    def load_product_data(self, file_path: str = "Amazon_products.csv"):
        """Load and preprocess product data"""
        self.df = pd.read_csv(file_path)
        self._preprocess_data()
        
        if self.recommender_type == RecommenderType.RAG:
            self._build_rag_index()
        else:
            self._build_tfidf_matrix()
    
    def _preprocess_data(self):
        """Preprocess product data"""
        # Clean text fields
        self.df['name'] = self.df['name'].apply(self._clean_text)
        self.df['main_category'] = self.df['main_category'].apply(self._clean_category)
        self.df['sub_category'] = self.df['sub_category'].apply(self._clean_category)

        # Process prices and ratings
        self.df['discount_price'] = self.df['discount_price'].apply(self._process_price)
        self.df['actual_price'] = self.df['actual_price'].apply(self._process_price)
        self.df['ratings'] = pd.to_numeric(self.df['ratings'], errors='coerce')
        self.df['ratings'] = self.df['ratings'].fillna(self.df['ratings'].mean())

        # Create tags for TFIDF
        self._create_tags()

    def _clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        if not isinstance(text, str):
            return ""
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text.lower())
        return ' '.join(word for word in text.split() if len(word) > 2)

    def _clean_category(self, category: str) -> str:
        """Clean and standardize category names"""
        if isinstance(category, str):
            category = category.lower().strip()
            category = category.replace('&', 'and')
            category = category.replace(',', '')
            if "home" in category:
                category = 'home and kitchen'
        return category

    def _process_price(self, price: Any) -> Optional[float]:
        """Process price values"""
        if isinstance(price, str):
            price = re.sub(r'[^\d.]', '', price)
            try:
                return float(price)
            except ValueError:
                return None
        return price

    def _create_tags(self):
        """Create tags for content-based filtering"""
        columns = ['name', 'main_category', 'sub_category']
        self.df['Tags'] = self.df[columns].apply(
            lambda x: ' '.join([str(text) for text in x if pd.notnull(text)]), axis=1
        )
        self.df['Tags'] = self.df['Tags'].apply(self._clean_text)

    def _build_rag_index(self):
        """Build FAISS index for RAG-based recommendations"""
        # Create product descriptions
        product_texts = self.df.apply(
            lambda x: f"{x['name']} {x['main_category']} {x['sub_category']}", axis=1
        ).tolist()
        
        # Get embeddings
        self.product_embeddings = self.embedding_model.encode(product_texts)
        
        # Build FAISS index
        dimension = self.product_embeddings.shape[1]
        self.faiss_index = faiss.IndexFlatL2(dimension)
        self.faiss_index.add(self.product_embeddings)
    
    def _build_tfidf_matrix(self):
        """Build TF-IDF matrix for traditional recommendations"""
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(self.df['Tags'])
        self.cosine_sim_matrix = cosine_similarity(self.tfidf_matrix)

    def get_recommendations(self, query: str, metadata: Optional[Dict[str, Any]] = None, top_n: int = 5) -> pd.DataFrame:
        """Get product recommendations using selected method"""
        if self.recommender_type == RecommenderType.RAG:
            print("Using RAG for recommendations")
            return self._get_rag_recommendations(query, metadata, top_n)
        else:
            print("Using TF-IDF for recommendations")
            return self._get_tfidf_recommendations(query, metadata, top_n)
    
    @lru_cache(maxsize=1000)
    def _embed_text(self, text: str) -> np.ndarray:
        """Get embedding for text with caching"""
        return self.embedding_model.encode([text])[0]
    
    def _get_rag_recommendations(self, query: str, metadata: Optional[Dict[str, Any]], top_n: int) -> pd.DataFrame:
        """Get recommendations using RAG with improved caching"""
        # Get query embedding
        query_embedding = self._embed_text(query)
        
        # Search FAISS index
        distances, indices = self.faiss_index.search(
            query_embedding.reshape(1, -1), 
            top_n * 2  # Get more results for filtering
        )
        
        # Get candidate recommendations and create similarity scores
        recommendations = self.df.iloc[indices[0]].copy()  # Create explicit copy
        recommendations.loc[:, 'similarity_score'] = 1 - distances[0]  # Use .loc to avoid warning

        # Apply metadata filters
        if metadata:
            recommendations = self._apply_metadata_filters(recommendations, metadata)
        # print("Recommendations after metadata filtering: ", recommendations.head(top_n))
        # Ensure we don't exceed top_n
        return recommendations.head(top_n)

    def _get_tfidf_recommendations(self, query: str, metadata: Optional[Dict[str, Any]], top_n: int) -> pd.DataFrame:
        """Get recommendations using TF-IDF"""
        query_vector = self.tfidf_vectorizer.transform([query])
        sim_scores = cosine_similarity(query_vector, self.tfidf_matrix)[0]
        
        recommendations = self.df.copy()
        recommendations['similarity_score'] = sim_scores

        if metadata:
            recommendations = self._apply_metadata_filters(recommendations, metadata)
            # print("Recommendations after metadata filtering: ", recommendations.sort_values('similarity_score', ascending=False).head(top_n))
        
        return recommendations.sort_values('similarity_score', ascending=False).head(top_n)

    def _apply_metadata_filters(self, recommendations: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        """Apply filters based on metadata"""
        if not isinstance(metadata, dict):
            return recommendations

        filtered_df = recommendations.copy()

        # Apply price range filters
        if price_range := metadata.get('price_range'):
            if min_price := price_range.get('min'):
                filtered_df = filtered_df[filtered_df['discount_price'] >= min_price]
            if max_price := price_range.get('max'):
                filtered_df = filtered_df[filtered_df['discount_price'] <= max_price]

        # Apply category filters
        if product_type := metadata.get('product_type'):
            filtered_df = filtered_df[
                filtered_df['main_category'].str.contains(str(product_type), case=False, na=False) |
                filtered_df['sub_category'].str.contains(str(product_type), case=False, na=False)
            ]

        # Apply quality/rating filters
        if quality_prefs := metadata.get('quality_preferences'):
            if isinstance(quality_prefs, list):
                quality_pref = ' '.join(quality_prefs).lower()
            else:
                quality_pref = str(quality_prefs).lower()
                
            if any(term in quality_pref for term in ['high', 'best', 'top']):
                filtered_df = filtered_df[filtered_df['ratings'] >= 4.0]
            elif 'good' in quality_pref:
                filtered_df = filtered_df[filtered_df['ratings'] >= 3.5]

        # Apply brand filters
        if brands := metadata.get('brands'):
            if isinstance(brands, list) and brands:
                brand_pattern = '|'.join(map(str, brands))
                filtered_df = filtered_df[
                    filtered_df['name'].str.contains(brand_pattern, case=False, na=False)
                ]

        # Return original if no results after filtering
        return filtered_df if not filtered_df.empty else recommendations

    def analyze_query(self, query: str) -> Dict[str, Any]:
        """Analyze query and extract metadata"""
        intent = self.classify_intent(query)
        print("Intent classified as : "+ intent)        

        metadata = {
            'product_type': None,
            'specific_requirements': [],
            'price_range': None,
            'quality_preferences': [],
            'style_preferences': [],
            'brands': [],
            'filters': {}
        }

        if intent == "Product Search":
            metadata = self._extract_metadata(query)
            # metadata = self._fallback_metadata(query)
            print("Metadata extracted: ", metadata) 

        metadata['intent'] = intent

        return metadata

    def _create_analysis_prompt(self, query: str) -> str:
        """Create structured prompt for query analysis"""
        return f"""### Instruction:
Analyze this shopping query and extract structured metadata:
"{query}"

Return a JSON object with:
- product_type: main product category
- specific_requirements: [list of features/attributes]
- price_range: {{"min": X, "max": Y}} or null
- quality_preferences: [quality/rating preferences]
- style_preferences: [style/aesthetic preferences]
- brands: [mentioned brands] or null
- filters: {{"key": "value"}}

Output:"""
    
    def _extract_metadata(self, query: str) -> Dict[str, Any]:
        """Extract metadata using configured approach"""
        if self.config.metadata_type == MetadataExtractorType.RULE_BASED:
            return self._fallback_metadata(query)
        
        try:
            # Model-based extraction
            prompt = self._create_analysis_prompt(query)
            inputs = self.query_tokenizer(prompt, return_tensors="pt")
            for key, value in inputs.items():
                if hasattr(value, 'to'):
                    inputs[key] = value.to(self.device)
            
            with torch.no_grad():
                outputs = self.query_model.generate(
                    **inputs,
                    max_new_tokens=512,
                    temperature=0.2,
                    top_p=0.95,
                    do_sample=True
                )
                if self.device != "cpu":
                    outputs = outputs.cpu()
                    
            response = self.query_tokenizer.decode(outputs[0], skip_special_tokens=True)
            metadata = self._extract_metadata_from_response(response, query)
            
            # Add price range if not present
            if not metadata.get('price_range'):
                price_range = self._extract_price_range(query)
                if price_range:
                    metadata['price_range'] = price_range
                    
            return metadata
        except Exception as e:
            print(f"Error during model-based metadata extraction: {str(e)}")
            return self._fallback_metadata(query)

    def _extract_metadata_from_response(self, response: str, query: str) -> Dict[str, Any]:
        """Extract metadata from model response"""
        try:
            # Find JSON content between Output: and any subsequent text
            start_marker = "Output:"
            start_idx = response.find(start_marker)
            if start_idx >= 0:
                json_text = response[start_idx + len(start_marker):].strip()
            else:
                json_text = response

            # Clean up the JSON text
            json_text = json_text.strip()
            if not json_text.startswith('{'):
                # Try to find the first occurrence of {
                start_brace = json_text.find('{')
                if start_brace >= 0:
                    json_text = json_text[start_brace:]
                else:
                    raise ValueError("No JSON object found in response")

            # Find the matching closing brace
            brace_count = 0
            end_pos = -1
            for i, char in enumerate(json_text):
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        end_pos = i + 1
                        break
            
            if end_pos > 0:
                json_text = json_text[:end_pos]
            
            # Parse JSON
            metadata = json.loads(json_text)
            
            # Add price range from regex if not present
            if not metadata.get('price_range'):
                price_range = self._extract_price_range(query)
                if price_range:
                    metadata['price_range'] = price_range
                    
            return metadata
        except Exception as e:
            print(f"Error extracting metadata json from llm response: {str(e)}")
            print(f"Response text: {response}")
            return self._fallback_metadata(query)

    def _extract_price_range(self, text: str) -> Dict[str, float]:
        """Extract price range from text"""
        text = text.lower()
        price_range = {"min": None, "max": None}
        
        # Extract maximum price
        max_patterns = [
            r"under (?:rs\.?|₹)?\s*(\d+)",
            r"less than (?:rs\.?|₹)?\s*(\d+)",
            r"up to (?:rs\.?|₹)?\s*(\d+)",
            r"(?:rs\.?|₹)?\s*(\d+) or less"
        ]
        
        for pattern in max_patterns:
            if match := re.search(pattern, text):
                try:
                    price_range["max"] = float(match.group(1))
                    break
                except ValueError:
                    continue
        
        # Extract minimum price
        min_patterns = [
            r"above (?:rs\.?|₹)?\s*(\d+)",
            r"more than (?:rs\.?|₹)?\s*(\d+)",
            r"(?:rs\.?|₹)?\s*(\d+) or more"
        ]
        
        for pattern in min_patterns:
            if match := re.search(pattern, text):
                try:
                    price_range["min"] = float(match.group(1))
                    break
                except ValueError:
                    continue
        
        return price_range if price_range["min"] or price_range["max"] else None

    def _fallback_metadata(self, query: str) -> Dict[str, Any]:
        """Rule-based fallback for metadata extraction"""
        query = query.lower()
        
        # Basic category detection
        # categories = ['clothing', 'shoes', 'electronics', 'jewelry', 'accessories',
        #             'home', 'kitchen', 'books', 'beauty', 'sports']
        categories = ['Western Wear', 'All Appliances', 'Shirts', 'Sports Shoes',
       'T-shirts & Polos', "Kids' Watches", 'Gold & Diamond Jewellery',
       'Innerwear', 'Fashion & Silver Jewellery', 'Formal Shoes',
       'Household Supplies', 'Fashion Sandals', 'Casual Shoes',
       'Nursing & Feeding', 'Bags & Luggage', 'Jeans',
       'Garden & Outdoors', 'Clothing', 'Lingerie & Nightwear',
       'Speakers', 'Car Parts', 'Sportswear', 'Cameras', 'Jewellery',
       'All Electronics', "Men's Fashion", 'Heating & Cooling Appliances',
       'Ballerinas', 'Coffee, Tea & Beverages',
       'Home Entertainment Systems', 'Headphones',
       'The Designer Boutique', 'Kitchen & Home Appliances',
       'Amazon Fashion', 'Security Cameras', 'Watches',
       'Camera Accessories', 'School Bags', 'Handbags & Clutches',
       'Ethnic Wear', 'Make-up', 'Strength Training', 'Diet & Nutrition',
       'Rucksacks', 'Furniture', "Kids' Clothing", 'Toys & Games',
       'All Home & Kitchen', 'All Grocery & Gourmet Foods',
       'Washing Machines', 'Televisions', 'Sewing & Craft Supplies',
       'Travel Accessories', 'All Exercise & Fitness',
       'All Sports, Fitness & Outdoors', 'Backpacks', 'Bedroom Linen',
       'Dog supplies', 'Car Accessories', "Women's Fashion",
       'Refrigerators', 'Cricket', 'Luxury Beauty', 'Snack Foods',
       'Home Storage', 'Test, Measure & Inspect', 'Fitness Accessories',
       'Home Improvement', 'Baby Fashion', 'Air Conditioners', 'Yoga',
       'Beauty & Grooming', 'Diapers', 'Cycling', 'Wallets',
       'Musical Instruments & Professional Audio', 'Sunglasses',
       "Kids' Shoes", 'Home Furnishing', 'Personal Care Appliances',
       'Badminton', 'Football', 'Home Décor', "Kids' Fashion",
       'Lab & Scientific', 'Home Audio & Theater',
       'Baby Bath, Skin & Grooming', 'Suitcases & Trolley Bags',
       'Running', 'Refurbished & Open Box', 'Health & Personal Care',
       'Strollers & Prams', 'Car & Bike Care', 'Shoes',
       'All Car & Motorbike Products', 'Kitchen & Dining',
       'Janitorial & Sanitation Supplies',
       'Industrial & Scientific Supplies', 'Travel Duffles',
       'Car Electronics', 'Cardio Equipment',
       'Motorbike Accessories & Parts', 'All Pet Supplies',
       'Camping & Hiking', 'Indoor Lighting',
       'Kitchen Storage & Containers', 'Baby Products', 'Value Bazaar']
        product_type = next((cat for cat in categories if cat in query), None)
        
        # Quality preferences
        quality_terms = ['best', 'top rated', 'high quality', 'premium', 'highly rated']
        quality_prefs = next((term for term in quality_terms if term in query), None)
        
        return {
            'product_type': product_type,
            'specific_requirements': [],
            'price_range': self._extract_price_range(query),
            'quality_preferences': [quality_prefs] if quality_prefs else [],
            'style_preferences': [],
            'brands': [],
            'filters': {}
        }

    def classify_intent(self, query: str) -> str:
        """Classify intent using configured approach"""
        if self.config.intent_type == IntentClassificationType.RULE_BASED:
            return self._rule_based_intent(query)
            
        try:
            candidate_labels = ["Product Search", "General Query", "Feedback"]
            result = self.intent_classifier(
                query,
                candidate_labels=candidate_labels,
                multi_label=False
            )
            return result['labels'][0] if result['scores'][0] > 0.4 else "General Query"
        except Exception as e:
            print(f"Model-based intent classification error: {str(e)}")
            return self._rule_based_intent(query)

    def _rule_based_intent(self, query: str) -> str:
        """Rule-based intent classification"""
        if not query or not isinstance(query, str):
            return "Not clear"
            
        query = query.lower()
        if any(term in query for term in ["feedback", "thanks", "good", "bad", "great", 
                                        "helpful", "not helpful", "like", "dislike"]):
            return "Feedback"
        elif any(term in query for term in ["help", "find", "search", "show", "recommend", 
                                          "suggest", "looking for", "want", "need", "searching"]):
            return "Product Search"
        elif any(term in query for term in ["hi", "hello", "hey", "greetings", 
                                          "how are you", "what's up"]):
            return "Greeting"
        else:
            return "General Query"

    def analyze_sentiment(self, text: str) -> tuple[str, float]:
        """Analyze sentiment using configured approach"""
        if self.config.sentiment_type == SentimentAnalyzerType.RULE_BASED:
            return self._rule_based_sentiment(text)
        
        try:
            result = self.sentiment_analyzer(text)[0]
            
            if self.config.sentiment_type == SentimentAnalyzerType.BERT_MULTILINGUAL:
                # BERT returns 1-5 stars
                score = int(result['label'].split()[0])
                confidence = result['score']
                
                if score >= 4:
                    sentiment = "Positive"
                elif score == 3:
                    sentiment = "Neutral"
                else:
                    sentiment = "Negative"
            else:  # ROBERTA_TWITTER
                # RoBERTa returns negative/neutral/positive
                label = result['label'].lower()
                confidence = result['score']
                
                if 'positive' in label:
                    sentiment = "Positive"
                elif 'negative' in label:
                    sentiment = "Negative"
                else:
                    sentiment = "Neutral"
                
            return sentiment, confidence
        except Exception as e:
            print(f"Sentiment analysis error: {str(e)}")
            return self._rule_based_sentiment(text)
    
    def _rule_based_sentiment(self, text: str) -> tuple[str, float]:
        """Fallback rule-based sentiment analysis"""
        text = text.lower()
        
        positive_words = {'good', 'great', 'awesome', 'excellent', 'thank', 'thanks', 'helpful', 'perfect', 'amazing', 'love', 'best'}
        negative_words = {'bad', 'poor', 'terrible', 'worst', 'hate', 'useless', 'waste', 'disappointing', 'awful'}
        
        pos_count = sum(1 for word in positive_words if word in text)
        neg_count = sum(1 for word in negative_words if word in text)
        
        total = pos_count + neg_count
        if total == 0:
            return "Neutral", 0.5
        
        if pos_count > neg_count:
            return "Positive", pos_count / (pos_count + neg_count)
        elif neg_count > pos_count:
            return "Negative", neg_count / (pos_count + neg_count)
        else:
            return "Neutral", 0.5

def format_product_recommendations(recommendations: pd.DataFrame, metadata: Dict[str, Any] = None) -> str:
    """Format product recommendations for WhatsApp message"""
    if recommendations.empty:
        return "Sorry, I couldn't find any matching products."
    
    # Add context based on metadata
    context = ""
    if metadata:
        if metadata.get('occasion'):
            context += f"For {metadata['occasion']}: "
        if metadata.get('style_preferences'):
            context += f"Matching your {', '.join(metadata['style_preferences'])} style preferences: "
    
    message = f"🛍️ {context}Here are some products you might like:\n\n"

    for _, product in recommendations.iterrows():
        message += f"📌 {product['name']}\n"
        message += f"   Category: {product['main_category']} > {product['sub_category']}\n"
        message += f"   Price: ₹{product['discount_price']:.2f}"

        if pd.notna(product.get('actual_price')):
            actual_price = pd.to_numeric(product['actual_price'], errors='coerce')
            discount_price = pd.to_numeric(product['discount_price'], errors='coerce')
            if actual_price and actual_price > discount_price:
                savings = ((actual_price - discount_price) / actual_price) * 100
                message += f" (Save {savings:.0f}%!)"
        message += "\n"

        if pd.notna(product.get('ratings')):
            ratings = pd.to_numeric(product['ratings'], errors='coerce')
            if not pd.isna(ratings):
                message += f"   Rating: {'⭐' * int(ratings)} ({ratings:.1f})"

        if pd.notna(product.get('no_of_ratings')):
            no_of_ratings = pd.to_numeric(product['no_of_ratings'], errors='coerce')
            if not pd.isna(no_of_ratings):
                message += f" ({int(no_of_ratings)} reviews)"
        message += "\n\n"

    # Add tips based on metadata
    if metadata:
        if metadata.get('price_range'):
            message += "\n💡 Tip: You can specify a different price range! 💰"
        if metadata.get('specific_requirements'):
            message += "\n💡 Tip: Try being more specific about features you want! 🎯"
    
    return message

def process_message(message: str, sender_number: str, profile_name: str) -> str:
    """Process incoming message and generate response"""
    # Get user context
    with db_manager.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            'SELECT context, timestamp FROM user_context WHERE user_number = ?', 
            (sender_number,)
        )
        row = cursor.fetchone()
        
        if row:
            context = json.loads(row[0])
            timestamp = datetime.datetime.fromisoformat(row[1])
            user_context = UserContext(sender_number, context, timestamp)
            
            # Check for context expiry
            if user_context.is_expired(datetime.timedelta(hours=1)):
                cursor.execute('DELETE FROM user_context WHERE user_number = ?', (sender_number,))
                conn.commit()
                return "Your session has expired. Let's start fresh! How can I help you today? 😊"
        else:
            context = {}
    
    if message.lower() in ['reset context', 'clear context']:
        with db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM user_context WHERE user_number = ?', (sender_number,))
            conn.commit()
        return "Your context has been reset. You can start a new session now! 😊"
    
    elif message.lower().startswith('reset '):
        reset_key = message[6:].strip().lower()
        if reset_key in context:
            del context[reset_key]
            with db_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    'UPDATE user_context SET context = ? WHERE user_number = ?',
                    (json.dumps(context), sender_number)
                )
                conn.commit()
            return f"Your {reset_key} preferences have been reset."
        return f"I couldn't find {reset_key} in your context to reset."
    
    elif message.lower() in ['what is my context', 'show context']:
        if context:
            return "Here is your current context:\n" + "\n".join([
                f"{key}: {value}" for key, value in context.items()
            ])
        return "Your context is currently empty."        
    
    # Regular message processing
    metadata = llm_engine.analyze_query(message)
    intent = metadata.get('intent')
    print("Intent classified as from process_message: "+ intent)
    if intent == "Greeting":

        response = "Hi, I'm here to help you find products! Try asking something like:\n" \
                  "🔍 'Find me casual shoes under 2000'\n" \
                  "🌟 'Show best rated electronics'\n" \
                  "👗 'Looking for party wear dresses'\n" \
                  "🎁 'Recommend anniversary gift ideas'"
        return response
    
    elif intent == "General Query":
        response = "I'm extracting response using general query model. \n"
        response += llm_engine.generate_response(message)
        return response

    elif intent == "Product Search":
        context.update(metadata)
        with db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO user_context (user_number, context, timestamp)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(user_number) DO UPDATE SET
                context = ?, timestamp = CURRENT_TIMESTAMP
            ''', (sender_number, json.dumps(context), json.dumps(context)))
            conn.commit()

        # Get recommendations
        print("Searching for products")
        recommendations = llm_engine.get_recommendations(message, metadata)
        response = format_product_recommendations(recommendations, metadata)
        
        print(response)
        # Add engagement prompt
        response += "\n\n💬 Was this helpful? Let me know with 'Feedback: [your thoughts]'!"
        response += "\n🔄 You can also try refining your search or asking for something different."
    
    elif intent == "Feedback":
        response = "Thank you for your feedback!"

    else:
        response = "I'm not sure what you're looking for. Could you try rephrasing your request? 🤔"

    # Save conversation
    sentiment, confidence = llm_engine.analyze_sentiment(message)
    print(f"Sentiment: {sentiment}, Confidence: {confidence}")
    with db_manager.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO conversations 
            (user_number, profile_name, user_message, bot_response, sentiment, confidence)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (sender_number, profile_name, message, response, sentiment, confidence))
        conn.commit()
    
    return response

# Initialize Flask app
app = Flask(__name__)

# Load environment variables
load_dotenv()

# Initialize global instances
db_manager = DatabaseManager('shopping_assistant.db')
# llm_engine = UnifiedLLMEngine(recommender_type=RecommenderType.RAG)  # Can be changed to TFIDF
llm_engine = UnifiedLLMEngine(recommender_type=RecommenderType.TFIDF)  # Can be changed to TFIDF

@app.route('/')
def index():
    return jsonify({
        'status': 'online',
        'endpoints': {
            'webhook': '/webhook',
            'dashboard': '/dashboard'
        }
    })

@app.route('/webhook', methods=['GET', 'POST'])
def webhook():
    if request.method == 'GET':
        return Response(status=200)
    
    try:
        # Get message details
        incoming_msg = request.values.get('Body', '').strip()
        sender_number = request.values.get('From', '').strip().replace('whatsapp:', '')
        profile_name = request.values.get('ProfileName', '') or sender_number

        # Process message
        response_text = process_message(incoming_msg, sender_number, profile_name)

        # Create Twilio response
        resp = MessagingResponse()
        resp.message(response_text)
        print(str(resp))

        MAX_LENGTH = 1500  # Leave room for additional formatting
        if len(response_text) > MAX_LENGTH:
            print("Length > 1500")
            response_text = response_text[:MAX_LENGTH] + "... [Message truncated]"

        return Response(str(resp), mimetype='application/xml')

    except Exception as e:
        print(f"Webhook error: {str(e)}")
        resp = MessagingResponse()
        resp.message("I encountered an error. Please try again.")
        return Response(str(resp), mimetype='application/xml')

@app.route('/dashboard')
def dashboard():
    # Get conversation data from database
    with db_manager.get_connection() as conn:
        # Load into pandas for analysis
        conversations_df = pd.read_sql_query('''
            SELECT sentiment, confidence, timestamp,
                   COUNT(*) as count,
                   strftime('%Y-%m-%d', timestamp) as date
            FROM conversations
            WHERE timestamp >= date('now', '-30 day')
            GROUP BY sentiment, date
            ORDER BY date
        ''', conn)
        
        # Get feedback data
        feedback_df = pd.read_sql_query('''
            SELECT feedback_text, rating, timestamp
            FROM feedback
            WHERE timestamp >= date('now', '-30 day')
            ORDER BY timestamp DESC
        ''', conn)

    # Create sentiment trend chart
    sentiment_fig = px.line(conversations_df, 
                          x='date', 
                          y='count', 
                          color='sentiment',
                          title='Sentiment Trends (Last 30 Days)')
    
    # Create confidence distribution
    confidence_fig = px.histogram(conversations_df, 
                                x='confidence',
                                color='sentiment',
                                title='Confidence Score Distribution')

    # Create sentiment donut chart
    sentiment_counts = conversations_df.groupby('sentiment')['count'].sum()
    donut_fig = go.Figure(data=[go.Pie(labels=sentiment_counts.index, 
                                      values=sentiment_counts.values,
                                      hole=.3)])
    donut_fig.update_layout(title='Overall Sentiment Distribution')

    dashboard_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>WhatsApp Shopping Assistant Dashboard</title>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .chart-container { margin-bottom: 30px; }
            .feedback-container { margin-top: 30px; }
            .stats-card { margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="container mt-4">
            <h1>WhatsApp Shopping Assistant Analytics</h1>
            
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card stats-card">
                        <div class="card-body">
                            <h5 class="card-title">Positive Rate</h5>
                            <h2 class="card-text">{{ positive_rate }}%</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stats-card">
                        <div class="card-title">
                            <h5 class="card-title">Average Confidence</h5>
                            <h2 class="card-text">{{ avg_confidence }}%</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stats-card">
                        <div class="card-body">
                            <h5 class="card-title">Total Conversations</h5>
                            <h2 class="card-text">{{ total_conversations }}</h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 chart-container">
                    <div class="card">
                        <div class="card-body">
                            {{ sentiment_trend | safe }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 chart-container">
                    <div class="card">
                        <div class="card-body">
                            {{ sentiment_dist | safe }}
                        </div>
                    </div>
                </div>
                <div class="col-md-6 chart-container">
                    <div class="card">
                        <div class="card-body">
                            {{ confidence_dist | safe }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="row feedback-container">
                <div class="col-md-12">
                    <h3>Recent Feedback</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Feedback</th>
                                    <th>Rating</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for _, row in feedback_data.iterrows() %}
                                <tr>
                                    <td>{{ row.timestamp }}</td>
                                    <td>{{ row.feedback_text }}</td>
                                    <td>{{ "⭐" * row.rating if row.rating else "" }}</td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """

    # Calculate statistics
    total_conversations = conversations_df['count'].sum()
    positive_rate = (conversations_df[conversations_df['sentiment'] == 'Positive']['count'].sum() / 
                    total_conversations * 100) if total_conversations > 0 else 0
    avg_confidence = conversations_df['confidence'].mean() * 100

    return render_template_string(
        dashboard_template,
        sentiment_trend=sentiment_fig.to_html(full_html=False),
        sentiment_dist=donut_fig.to_html(full_html=False),
        confidence_dist=confidence_fig.to_html(full_html=False),
        positive_rate=f"{positive_rate:.1f}",
        avg_confidence=f"{avg_confidence:.1f}",
        total_conversations=total_conversations,
        feedback_data=feedback_df
    )

if __name__ == '__main__':
    try:
        # Configure ngrok
        if NGROK_AUTH_TOKEN := os.getenv('NGROK_AUTH_TOKEN'):
            conf.get_default().auth_token = NGROK_AUTH_TOKEN
            public_url = ngrok.connect(5000)
            print(f'🌐 Public URL: {public_url}')
            print('📝 Use this URL in your Twilio Webhook configuration:')
            print(f'   {public_url}/webhook')
        else:
            raise ValueError("NGROK_AUTH_TOKEN environment variable is required")

        # Start Flask app
        app.run(port=5000)
    except Exception as e:
        print(f"❌ Startup error: {str(e)}")