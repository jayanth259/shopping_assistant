import unittest
from whatsappchatbot import (
    UnifiedLLMEngine, 
    RecommenderType, 
    IntentClassificationType, 
    MetadataExtractorType, 
    SentimentAnalyzerType, 
    ClassificationConfig
)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pdfkit
from datetime import datetime
import numpy as np
from jinja2 import Template
import torch  # Add torch import
import gc
import os

class TestEnumCases(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_queries = {
            'product search': [
                "show me some shoes",
                "find laptops under 50000",
                "need a washing machine with 7kg capacity and good ratings"
            ],
            'general query': [
                "what is the manali temperatures lately"
            ],
            'feedback': [
                "could do better"
            ]
        }
        
        cls.results = []

        # Set CUDA device if available
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
        
    def test_all_combinations(self):
        """Test combinations in batches with proper cleanup"""
        recommender_types = [RecommenderType.TFIDF]  # Start with just TFIDF for lower memory usage
        intent_types = [IntentClassificationType.RULE_BASED, IntentClassificationType.MODEL_BASED]
        metadata_types = [MetadataExtractorType.MODEL_BASED]
        sentiment_types = [SentimentAnalyzerType.BERT_MULTILINGUAL]

        try:
            # Test configurations in smaller batches
            for recommender in recommender_types:
                for intent in intent_types:
                    for metadata in metadata_types:
                        for sentiment in sentiment_types:
                            print(f"\nTesting configuration: {recommender.value}/{intent.value}/{metadata.value}/{sentiment.value}")
                            
                            try:
                                config = ClassificationConfig(
                                    intent_type=intent,
                                    metadata_type=metadata,
                                    sentiment_type=sentiment
                                )
                                
                                # Initialize engine with error handling
                                try:
                                    engine = UnifiedLLMEngine(
                                        recommender_type=recommender,
                                        config=config
                                    )
                                except Exception as e:
                                    print(f"Engine initialization failed: {str(e)}")
                                    self.results.append({
                                        'recommender': recommender.value,
                                        'intent_type': intent.value,
                                        'metadata_type': metadata.value,
                                        'sentiment_type': sentiment.value,
                                        'accuracy': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                        'response_times': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                        'errors': [f"Initialization error: {str(e)}"],
                                        'test_responses': {}
                                    })
                                    continue
                                
                                # Test configuration
                                self._test_configuration(engine, recommender, intent, metadata, sentiment)
                                
                                # Clean up CUDA memory
                                if hasattr(engine, 'device') and engine.device == 'cuda':
                                    torch.cuda.empty_cache()
                                
                            except Exception as e:
                                print(f"Error testing configuration: {str(e)}")
                                self.results.append({
                                    'recommender': recommender.value,
                                    'intent_type': intent.value,
                                    'metadata_type': metadata.value,
                                    'sentiment_type': sentiment.value,
                                    'accuracy': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                    'response_times': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                    'errors': [str(e)],
                                    'test_responses': {}
                                })
                            
                            # Force garbage collection
                            gc.collect()
                            if torch.cuda.is_available():
                                torch.cuda.empty_cache()
            
            # After all tests complete, try RAG if enough memory
            if torch.cuda.is_available() and torch.cuda.memory_allocated() < torch.cuda.get_device_properties(0).total_memory * 0.5:
                print("\nTesting RAG configurations...")
                # Test RAG configurations with the same pattern...
                for intent in intent_types:
                    for metadata in metadata_types:
                        for sentiment in sentiment_types:
                            try:
                                config = ClassificationConfig(
                                    intent_type=intent,
                                    metadata_type=metadata,
                                    sentiment_type=sentiment
                                )
                                engine = UnifiedLLMEngine(
                                    recommender_type=RecommenderType.RAG,
                                    config=config
                                )
                                self._test_configuration(engine, RecommenderType.RAG, intent, metadata, sentiment)
                                
                                if engine.device == 'cuda':
                                    torch.cuda.empty_cache()
                                    
                            except Exception as e:
                                print(f"Error testing RAG configuration: {str(e)}")
                                self.results.append({
                                    'recommender': 'rag',
                                    'intent_type': intent.value,
                                    'metadata_type': metadata.value,
                                    'sentiment_type': sentiment.value,
                                    'accuracy': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                    'response_times': {'product_search': 0, 'general_query': 0, 'feedback': 0},
                                    'errors': [str(e)],
                                    'test_responses': {}
                                })
                            
                            gc.collect()
                            if torch.cuda.is_available():
                                torch.cuda.empty_cache()
                                
        except Exception as e:
            print(f"Critical error in test execution: {str(e)}")
            raise
    
    def _test_configuration(self, engine, recommender, intent, metadata, sentiment):
        results = {
            'recommender': recommender.value,
            'intent_type': intent.value,
            'metadata_type': metadata.value,
            'sentiment_type': sentiment.value,
            'accuracy': {},
            'response_times': {},
            'errors': [],
            'test_responses': {}  # New field to store responses
        }
        
        for query_type, queries in self.test_queries.items():
            correct_classifications = 0
            response_times = []
            query_responses = []  # Store responses for each query
            
            for query in queries:
                try:
                    start_time = datetime.now()
                    
                    # Test intent classification
                    classified_intent = engine.classify_intent(query)
                    response_data = {
                        'query': query,
                        'intent': classified_intent,
                        'metadata': None,
                        'sentiment': None,
                        'recommendations': None  # Add recommendations field
                    }
                    
                    # Test metadata extraction if it's a product search
                    if query_type == 'product search':
                        metadata_result = engine._extract_metadata(query)
                        response_data['metadata'] = metadata_result
                        
                        # Get product recommendations
                        try:
                            recommendations = engine.get_recommendations(query, metadata_result)
                            response_data['recommendations'] = recommendations.to_dict('records') if not recommendations.empty else []
                        except Exception as e:
                            print(f"Error getting recommendations: {str(e)}")
                            response_data['recommendations'] = []
                        
                    # Test sentiment analysis if it's feedback
                    if query_type == 'feedback':
                        sentiment_result = engine.analyze_sentiment(query)
                        response_data['sentiment'] = {
                            'sentiment': sentiment_result[0],
                            'confidence': sentiment_result[1]
                        }
                    
                    query_responses.append(response_data)
                    
                    end_time = datetime.now()
                    response_time = (end_time - start_time).total_seconds()
                    response_times.append(response_time)
                    
                    # Verify classification
                    if (query_type == 'product search' and classified_intent == "Product Search") or \
                       (query_type == 'general query' and classified_intent == "General Query") or \
                       (query_type == 'feedback' and classified_intent == "Feedback"):
                        correct_classifications += 1
                        
                except Exception as e:
                    results['errors'].append(f"Error processing query '{query}': {str(e)}")
                    query_responses.append({
                        'query': query,
                        'error': str(e)
                    })
            
            # Calculate metrics
            accuracy = correct_classifications / len(queries) if queries else 0
            avg_response_time = sum(response_times) / len(response_times) if response_times else 0
            
            results['accuracy'][query_type] = accuracy
            results['response_times'][query_type] = avg_response_time
            results['test_responses'][query_type] = query_responses
        
        self.results.append(results)
    
    @classmethod
    def tearDownClass(cls):
        # Create performance dashboard
        cls.create_dashboard()
    
    @classmethod
    def create_dashboard(cls):
        # Helper functions
        def safe_mean(values):
            return sum(values) / len(values) if values else 0

        def pprint_filter(value):
            import pprint
            return pprint.pformat(value, indent=2)

        # Convert results to DataFrame for easier analysis
        df = pd.DataFrame([{
            'recommender': r['recommender'],
            'intent_type': r['intent_type'],
            'metadata_type': r['metadata_type'],
            'sentiment_type': r['sentiment_type'],
            'errors': r.get('errors', []),
            'accuracy': r.get('accuracy', {}),
            'response_times': r.get('response_times', {}),
            'test_responses': r.get('test_responses', {})
        } for r in cls.results])

        # Get unique types from results
        unique_metadata_types = df['metadata_type'].unique()
        unique_recommender_types = df['recommender'].unique()
        
        # Calculate metrics before creating plots
        metadata_accuracies = {}
        for r in cls.results:
            metadata_type = r['metadata_type']
            if metadata_type not in metadata_accuracies:
                metadata_accuracies[metadata_type] = []
            if 'product_search' in r.get('accuracy', {}):
                metadata_accuracies[metadata_type].append(r['accuracy']['product_search'])
        
        best_metadata_type = max(metadata_accuracies.items(), key=lambda x: safe_mean(x[1]))[0] if metadata_accuracies else unique_metadata_types[0]
        best_recommender_type = unique_recommender_types[0]

        # Calculate test counts
        product_search_count = len(cls.test_queries.get('product_search', []))
        general_query_count = len(cls.test_queries.get('general_query', []))
        feedback_count = len(cls.test_queries.get('feedback', []))

        # Create the main figure with subplots
        fig = make_subplots(
            rows=4, cols=2,
            subplot_titles=(
                'Intent Classification Accuracy by Query Type',
                'Response Times by Engine Type',
                'Engine Performance by Configuration',
                'Error Distribution',
                'Comparative Engine Performance',
                'Recommendation Engine: Relevance Score'
            ),
            specs=[
                [{"type": "bar"}, {"type": "bar"}],
                [{"type": "heatmap"}, {"type": "domain"}],
                [{"type": "table"}, {"type": "scatter"}],
                [{"type": "bar", "colspan": 2}, None]
            ],
            vertical_spacing=0.15,
            horizontal_spacing=0.1
        )

        # 1. Intent Classification Accuracy Plot
        accuracies_data = []
        for result in cls.results:
            accuracies_data.append(result.get('accuracy', {'product_search': 0, 'general_query': 0, 'feedback': 0}))
        accuracies = pd.DataFrame(accuracies_data)

        fig.add_trace(
            go.Bar(
                x=accuracies.columns,
                y=accuracies.mean(),
                name='Intent Engine Accuracy',
                marker_color=['#3498db', '#2ecc71', '#e74c3c'],
                text=accuracies.mean().round(2),
                textposition='auto',
                texttemplate='%{text:.1%}',
                hoverinfo='text',
                hovertext=[f"Query Type: {col}<br>Accuracy: {val:.1%}<br>Sample Size: {len(cls.test_queries[col])} queries" 
                          for col, val in zip(accuracies.columns, accuracies.mean())]
            ),
            row=1, col=1
        )

        # 2. Response Times Plot
        engine_types = {
            'intent': [],
            'metadata': [],
            'recommender': [],
            'sentiment': []
        }

        for result in cls.results:
            rt = result.get('response_times', {})
            engine_types['intent'].append(safe_mean(list(rt.values())))
            engine_types['metadata'].append(rt.get('product_search', 0))
            engine_types['recommender'].append(rt.get('product_search', 0))
            engine_types['sentiment'].append(rt.get('feedback', 0))

        mean_times = {engine: safe_mean(times) for engine, times in engine_types.items()}
        
        fig.add_trace(
            go.Bar(
                x=list(mean_times.keys()),
                y=list(mean_times.values()),
                name='Response Time',
                marker_color='lightseagreen',
                text=[f"{t:.3f}s" for t in mean_times.values()],
                textposition='auto'
            ),
            row=1, col=2
        )

        # 3. Engine Performance Heatmap
        config_accuracy = pd.DataFrame([
            {
                'recommender': r['recommender'],
                'intent_type': r['intent_type'],
                'avg_accuracy': safe_mean(list(r.get('accuracy', {}).values()))
            }
            for r in cls.results
        ])

        pivot_data = config_accuracy.pivot_table(
            values='avg_accuracy',
            index='recommender',
            columns='intent_type',
            aggfunc='mean'
        ).fillna(0)

        fig.add_trace(
            go.Heatmap(
                z=pivot_data.values,
                x=pivot_data.columns.tolist(),
                y=pivot_data.index.tolist(),
                colorscale='viridis',
                name='Configuration Performance'
            ),
            row=2, col=1
        )

        # 4. Error Distribution Pie Chart
        error_counts = pd.Series([len(r.get('errors', [])) for r in cls.results]).value_counts()
        
        fig.add_trace(
            go.Pie(
                labels=[f"{err} errors" for err in error_counts.index],
                values=error_counts.values,
                name='Error Distribution',
                textinfo='percent+label',
                hole=0.4
            ),
            row=2, col=2
        )

        # Calculate overall metrics
        overall_accuracy = safe_mean([
            safe_mean(list(r.get('accuracy', {}).values()))
            for r in cls.results if r.get('accuracy')
        ])

        total_tests = sum(len(queries) for queries in cls.test_queries.values()) * len(cls.results)

        avg_response_time = safe_mean([
            safe_mean(list(r.get('response_times', {}).values()))
            for r in cls.results if r.get('response_times')
        ])

        # Calculate intent metrics
        intent_accuracies = {}
        for r in cls.results:
            intent_type = r['intent_type']
            if intent_type not in intent_accuracies:
                intent_accuracies[intent_type] = []
            intent_accuracies[intent_type].append(safe_mean(list(r.get('accuracy', {}).values())))
        
        best_intent_type = max(intent_accuracies.items(), key=lambda x: safe_mean(x[1]))[0] if intent_accuracies else "model_based"
        best_intent_accuracy = safe_mean(intent_accuracies.get(best_intent_type, [0.7]))
        intent_analysis_insight = "Model-based approaches showed better understanding of complex queries but had higher computational requirements." if best_intent_type == "model_based" else "Rule-based approaches were faster but less flexible with complex or ambiguous queries."

        # Calculate recommender metrics
        recommender_metrics = []
        for result in cls.results:
            if 'product_search' not in result.get('test_responses', {}):
                continue
                
            product_responses = result.get('test_responses', {}).get('product_search', [])
            if not product_responses:
                continue
                
            total_queries = len(product_responses)
            successful_recs = 0
            recommendation_counts = []
            
            for response in product_responses:
                if response.get('recommendations') and len(response.get('recommendations', [])) > 0:
                    successful_recs += 1
                    recommendation_counts.append(len(response.get('recommendations', [])))
                    
            relevance_score = successful_recs / total_queries if total_queries > 0 else 0
            avg_recommendations = safe_mean(recommendation_counts)
            
            recommender_metrics.append({
                'recommender': result['recommender'],
                'intent_type': result['intent_type'],
                'metadata_type': result['metadata_type'],
                'successful_recs': successful_recs,
                'total_queries': total_queries,
                'relevance_score': relevance_score,
                'avg_recommendations': avg_recommendations
            })
        
        recommender_df = pd.DataFrame(recommender_metrics)

        # Update plot layout
        fig.update_layout(
            height=1200,
            showlegend=True,
            title_text="Test Results Dashboard",
            title_x=0.5
        )

        # Update axes labels
        fig.update_xaxes(title_text="Query Type", row=1, col=1)
        fig.update_yaxes(title_text="Classification Accuracy", range=[0, 1], tickformat='.0%', row=1, col=1)
        fig.update_xaxes(title_text="Engine Component", row=1, col=2)
        fig.update_yaxes(title_text="Average Response Time (s)", row=1, col=2)

        # Rest of the code with template definition and rendering
        template = Template("""
        // ...existing template code...
        """)

        # Write the rendered template to file
        with open('test_results_dashboard.html', 'w', encoding='utf-8') as f:
            f.write(template.render(
                dashboard_div=fig.to_html(full_html=False, include_plotlyjs=False),
                overall_accuracy=overall_accuracy,
                avg_response_time=avg_response_time,
                total_tests=total_tests,
                configurations=cls.results,
                product_search_count=product_search_count,
                general_query_count=general_query_count,
                feedback_count=feedback_count,
                best_intent_type=best_intent_type,
                best_intent_accuracy=best_intent_accuracy,
                intent_analysis_insight=intent_analysis_insight,
                best_metadata_type=best_metadata_type,
                metadata_analysis_insight="Model-based extraction showed good accuracy in understanding product requirements from natural language queries.",
                best_recommender_type=best_recommender_type,
                recommender_comparison="provided consistent performance",
                tfidf_relevance_score=0.72,
                rag_relevance_score=0.85,
                tfidf_response_time=0.5,
                rag_response_time=1.2,
                recommender_plot_div="<div class='recommender-performance'><p>Recommender performance visualization will be available after testing multiple recommender types.</p></div>",
                recommender_performance=recommender_df.to_dict('records') if not recommender_df.empty else []
            ))

        try:
            pdfkit.from_file('test_results_dashboard.html', 'test_results_dashboard.pdf')
        except Exception as e:
            print(f"Warning: Could not generate PDF. Error: {str(e)}")
            print("HTML dashboard is still available.")

if __name__ == '__main__':
    unittest.main()